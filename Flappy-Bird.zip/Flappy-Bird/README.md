# Flappy-Bird
CS50 Final project
So, I am saarth Jain. This CS50 final project in which I have finally made a flappy bird game . In this game if you prees P key so the game stops until you press P again you can use space key to fly the bird . If your score is more then 0 and less than 10 so you will be awarded a bronze medal and if less than 15 than silver medal and if greater than 15 than gold medal . So you can download my code.
Thank you
Saarth
